<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h4 class="text-footer">Contactanos</h4>
                <div class="social-icons">
                    <a href="https://wa.me/TU_NUMERO_DE_TELEFONO" target="_blank">
                        <i class="fa fa-whatsapp fa-2x" aria-hidden="true"></i>
                    </a>
                    <a href="https://t.me/TU_NOMBRE_DE_USUARIO" target="_blank">
                        <i class="fa fa-telegram fa-2x" aria-hidden="true"></i>
                    </a>
                    <a href="https://twitter.com/TU_NOMBRE_DE_USUARIO" target="_blank">
                        <i class="fa fa-twitter fa-2x" aria-hidden="true"></i>
                    </a>
                    <a href="https://www.facebook.com/TU_NOMBRE_DE_USUARIO" target="_blank">
                        <i class="fa fa-facebook fa-2x" aria-hidden="true"></i>
                    </a>
                    <a href="https://www.youtube.com/TU_CANAL" target="_blank">
                        <i class="fa fa-youtube-play fa-2x" aria-hidden="true"></i>
                    </a>
                    <a href="https://www.instagram.com/TU_NOMBRE_DE_USUARIO" target="_blank">
                        <i class="fa fa-instagram fa-2x" aria-hidden="true"></i>
                    </a>
                    <a href="https://www.google.com/maps/place/DIRECCION_DE_TU_NEGOCIO" target="_blank">
                        <i class="fa fa-map-marker fa-2x" aria-hidden="true"></i>
                    </a>
                </div>
            </div>

            <div class="col-sm-4">
                <h4 class="text-footer"></h4>
                <p>

                </p>
            </div>
            <div class="col-sm-4">

            </div>
        </div>
    </div>
    <br><br><br>
    <h5 class="text-center tittles-pages-logo text-footer">RESERVA TU CANCHA &copy; 2023</h5>
</footer>

